<?php

require_once dirname(__FILE__) . '/class-login-page-url.php';
