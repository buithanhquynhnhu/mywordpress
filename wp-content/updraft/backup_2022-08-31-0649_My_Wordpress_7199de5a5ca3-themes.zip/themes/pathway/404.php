<?php get_header(); ?>
<?php pathway_theme()->get( 'page-not-found' )->render(); ?>
<?php
get_footer();
