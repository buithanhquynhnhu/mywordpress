<li class="wp-block wp-block-kubio-iconlistitem position-relative wp-block-kubio-iconlistitem__item pathway-front-header__k__Rz_aukXfFPn-item pathway-local-suVgWBLnejx-item" data-kubio="kubio/iconlistitem">
	<div class="position-relative wp-block-kubio-iconlistitem__text-wrapper pathway-front-header__k__Rz_aukXfFPn-text-wrapper pathway-local-suVgWBLnejx-text-wrapper">
		<span class="h-svg-icon wp-block-kubio-iconlistitem__icon pathway-front-header__k__Rz_aukXfFPn-icon pathway-local-suVgWBLnejx-icon" name="icons8-line-awesome/envelope">
			<?php $icon = \ColibriWP\Theme\View::getData('icon'); if (isset($icon['content'])) echo $icon['content'] ?>
		</span>
		<span class="position-relative wp-block-kubio-iconlistitem__text pathway-front-header__k__Rz_aukXfFPn-text pathway-local-suVgWBLnejx-text">
			<?php echo esc_html(\ColibriWP\Theme\View::getData('text')); ?>
		</span>
	</div>
	<div class="last-el-spacer position-relative wp-block-kubio-iconlistitem__divider-wrapper pathway-front-header__k__Rz_aukXfFPn-divider-wrapper pathway-local-suVgWBLnejx-divider-wrapper"></div>
	<div class="position-relative wp-block-kubio-iconlistitem__divider-wrapper pathway-front-header__k__Rz_aukXfFPn-divider-wrapper pathway-local-suVgWBLnejx-divider-wrapper"></div>
</li>
