<span class="wp-block wp-block-kubio-button position-relative wp-block-kubio-button__outer pathway-front-header__k__krjLr6qWdH7-outer pathway-local-u0zp-0jJlfe-outer kubio-button-container" data-kubio="kubio/button">
	<a class="position-relative wp-block-kubio-button__link pathway-front-header__k__krjLr6qWdH7-link pathway-local-u0zp-0jJlfe-link h-w-100 h-global-transition" href="<?php echo esc_url(\ColibriWP\Theme\View::getData('url')); ?>">
		<span class="position-relative wp-block-kubio-button__text pathway-front-header__k__krjLr6qWdH7-text pathway-local-u0zp-0jJlfe-text kubio-inherit-typography">
			<?php echo esc_html(\ColibriWP\Theme\View::getData('label')); ?>
		</span>
	</a>
</span>
