<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<h1 class="wp-block wp-block-kubio-heading position-relative wp-block-kubio-heading__text pathway-front-header__k__ukjZtaF3MN-text pathway-local-JFYFJ_O2Gx-text" data-kubio="kubio/heading">
	<?php $component->printTitle(); ?>
</h1>
