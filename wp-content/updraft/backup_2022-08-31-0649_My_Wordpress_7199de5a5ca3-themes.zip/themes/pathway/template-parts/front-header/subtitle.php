<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<p class="wp-block wp-block-kubio-text position-relative wp-block-kubio-text__text pathway-front-header__k__IWMgUJsy_-text pathway-local-AGS4fRF4y4-text h-lead" data-kubio="kubio/text" id="paragraph">
	<?php $component->printSubtitle(); ?>
</p>
