<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<figure class="wp-block wp-block-kubio-image position-relative wp-block-kubio-image__outer pathway-front-header__k__2zxmcKbRuq-outer pathway-local-hyzZ6InSkv-outer size-large align-items-center" data-kubio="kubio/image">
	<div class="position-relative wp-block-kubio-image__captionContainer pathway-front-header__k__2zxmcKbRuq-captionContainer pathway-local-hyzZ6InSkv-captionContainer">
		<div class="position-relative wp-block-kubio-image__frameContainer pathway-front-header__k__2zxmcKbRuq-frameContainer pathway-local-hyzZ6InSkv-frameContainer">
			<?php $component->printImage(...array (
  0 => 'position-relative wp-block-kubio-image__image pathway-front-header__k__2zxmcKbRuq-image pathway-local-hyzZ6InSkv-image d-flex',
  1 => NULL,
)); ?>
<?php $component->printFrame('position-relative wp-block-kubio-image__frameImage'); ?>
		</div>
	</div>
</figure>
