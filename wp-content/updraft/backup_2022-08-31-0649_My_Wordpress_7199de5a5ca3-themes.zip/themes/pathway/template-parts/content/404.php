<div class="wp-block wp-block-kubio-section position-relative wp-block-kubio-section__outer pathway-404__k__TvUIu7nWc-outer pathway-local-VV_7654QcE-outer d-flex h-section-global-spacing align-items-lg-center align-items-md-center align-items-center" data-kubio="kubio/section">
	<div class="position-relative wp-block-kubio-section__inner pathway-404__k__TvUIu7nWc-inner pathway-local-VV_7654QcE-inner h-section-grid-container h-section-boxed-container">
		<div class="wp-block wp-block-kubio-row position-relative wp-block-kubio-row__container pathway-404__k__-raj3DSmnW-container pathway-local-MsHV-QZf3d-container gutters-row-lg-2 gutters-row-v-lg-0 gutters-row-md-2 gutters-row-v-md-2 gutters-row-2 gutters-row-v-2" data-kubio="kubio/row">
			<div class="position-relative wp-block-kubio-row__inner pathway-404__k__-raj3DSmnW-inner pathway-local-MsHV-QZf3d-inner h-row align-items-lg-start align-items-md-start align-items-start justify-content-lg-center justify-content-md-center justify-content-center gutters-col-lg-2 gutters-col-v-lg-0 gutters-col-md-2 gutters-col-v-md-2 gutters-col-2 gutters-col-v-2">
				<div class="wp-block wp-block-kubio-column position-relative wp-block-kubio-column__container pathway-404__k__TYq4YGB3vx-container pathway-local-qz8COS2e7J-container d-flex h-col-lg-auto h-col-md-auto h-col-auto align-self-lg-start align-self-md-start align-self-start" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner pathway-404__k__TYq4YGB3vx-inner pathway-local-qz8COS2e7J-inner d-flex h-flex-basis h-px-lg-2 v-inner-lg-2 h-px-md-2 v-inner-md-2 h-px-2 v-inner-2">
						<div class="position-relative wp-block-kubio-column__align pathway-404__k__TYq4YGB3vx-align pathway-local-qz8COS2e7J-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
							<div class="position-relative wp-block-kubio-home-button__ pathway-404__k__XE8iPl7Auw- pathway-local-4SwSo1BxoB-">
								<span class="wp-block wp-block-kubio-home-button position-relative wp-block-kubio-home-button__outer pathway-404__k__XE8iPl7Auw-outer pathway-local-4SwSo1BxoB-outer kubio-button-container" data-kubio="kubio/home-button">
									<a class="position-relative wp-block-kubio-home-button__link pathway-404__k__XE8iPl7Auw-link pathway-local-4SwSo1BxoB-link h-w-100 h-global-transition" href="<?php echo esc_url(home_url()); ?>">
										<span class="h-svg-icon wp-block-kubio-home-button__icon pathway-404__k__XE8iPl7Auw-icon pathway-local-4SwSo1BxoB-icon" name="icons8-line-awesome/home">
											<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="home" viewBox="0 0 512 545.5">
												<path d="M256 73.5l11.5 11 208 208-23 23L432 295v185H288V320h-64v160H80V295l-20.5 20.5-23-23 208-208zm0 45.5L112 263v185h80V288h128v160h80V263z"/></svg>
											</span>
											<span class="position-relative wp-block-kubio-home-button__text pathway-404__k__XE8iPl7Auw-text pathway-local-4SwSo1BxoB-text kubio-inherit-typography">
												<?php esc_html_e('Go to Homepage!', 'pathway'); ?>
											</span>
										</a>
									</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
