<h1 class="wp-block wp-block-kubio-page-title position-relative wp-block-kubio-page-title__container pathway-header__k__SzZXH7PdCL-container pathway-local-v74FlqW2oy-container" data-kubio="kubio/page-title">
	<?php pathway_print_page_title(); ?>
</h1>
