<a href="<?php echo esc_url(\ColibriWP\Theme\View::getData('link_value')); ?>" class="wp-block wp-block-kubio-social-icon position-relative wp-block-kubio-social-icon__link pathway-header__k__lzTFXJMPgxP-link pathway-local-vjHMqc_JWkh-link social-icon-link" data-kubio="kubio/social-icon">
	<span class="h-svg-icon wp-block-kubio-social-icon__icon pathway-header__k__lzTFXJMPgxP-icon pathway-local-vjHMqc_JWkh-icon" name="socicon/instagram">
		<?php $icon = \ColibriWP\Theme\View::getData('icon'); if (isset($icon['content'])) echo $icon['content'] ?>
	</span>
</a>
