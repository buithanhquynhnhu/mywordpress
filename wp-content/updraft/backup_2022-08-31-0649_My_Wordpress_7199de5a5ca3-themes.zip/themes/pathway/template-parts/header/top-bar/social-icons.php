<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<div class="wp-block wp-block-kubio-social-icons position-relative wp-block-kubio-social-icons__outer pathway-header__k__hJAAJkmTch9-outer pathway-local-7JIokBxGv3G-outer social-icons--container" data-kubio="kubio/social-icons">
	<?php $component->printIcons(); ?>
</div>
