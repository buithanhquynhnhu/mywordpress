<?php

get_header();

pathway_theme()->get( 'main' )->render();

get_footer();
