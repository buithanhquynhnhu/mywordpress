<?php get_header(); ?>
<?php pathway_theme()->get( 'content' )->render(); ?>
<?php
get_footer();
