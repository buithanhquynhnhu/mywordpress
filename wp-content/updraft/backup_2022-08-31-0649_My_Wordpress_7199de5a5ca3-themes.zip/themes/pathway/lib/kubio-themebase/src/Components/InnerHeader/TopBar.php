<?php


namespace Kubio\Theme\Components\InnerHeader;

class TopBar extends \ColibriWP\Theme\Components\Header\TopBar {
	static $settings_prefix = 'header.navigation.';
}
