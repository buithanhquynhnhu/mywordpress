<?php get_header(); ?>
<?php pathway_theme()->get( 'single' )->render(); ?>
<?php
get_footer();
